# -*- coding: utf-8 -*-
"""
step01_list.py

list 특징 
 - 순서 있는 자료구조
 형식) 변수 = [값1, 값2, ...]
"""

# 1. 단일 list & 색인 
lst = [1,2,3,4,5]
print(lst) # [1, 2, 3, 4, 5]
len(lst) # 5

# 색인(index) : 값의 위치
lst[:] # 전체 원소 
lst[0] # 첫번째 원소 
lst[-1] # 마지막 원소 

# list + for 이용 
for i in lst : 
    print(i, end = ' ') # 한 줄 중복 출력 


# 2. 중첩 list & 색인 
y = [['a','b','c'], [1,2,3]] 
print(y) 


# 3. list 값 수정(추가, 삽입, 수정, 삭제)
num = ['one', 2, 'three', 4]
print(num) # ['one', 2, 'three', 4]


# 1) list 값 추가 
num.append('five') 
print(num) # ['one', 2, 'three', 4, 'five']

# 2) list 값 삭제 
num.remove('three')
print(num) # ['one', 2, 4, 'five']

# 3) list 값 수정 
num[1] = 'two' 
print(num) # ['one', 'two', 4, 'five']

# 4) list 값 삽입 
num.insert(0, 'zero')
print(num)


# 4. list 연산 
x = [1, 2, 3, 4]
y = [1.5, 2.5]

# 1) list 결합(+)
z = x + y 
print(z) # [1, 2, 3, 4, 1.5, 2.5]

# 2) list 확장 
x.extend(y) 
print(x) # [1, 2, 3, 4, 1.5, 2.5]

# 3) list 추가 
x.append(y) 
print(x) # [1, 2, 3, 4, 1.5, 2.5, [1.5, 2.5]]

# 4) list 반복(*)
result = y * 2
print(result) # [1.5, 2.5, 1.5, 2.5]
    


# 5. list 정렬 & 색인 반환  

num.reverse() # 배열의 역순정렬(현재 객체 반영) 
 
num = [3,1,5,2]

# 숫자 원소 정렬 
num.sort() #  [1, 2, 3, 5] : 오름차순(현재 객체 반영)
num.sort(reverse=True) # [5, 3, 2, 1] : 내림차순(현재 객체 반영)


# 값의 색인 반환 
num.index(2) # 2
num.index('2') # ValueError: '2' is not in list



# 6. 빈 list에 값 추가와 원소 찾기 

num = [] # 빈 list : 숫자 저장 

# 임의 숫자 입력 
for i in range(5) : # 0~4
    num.append(int(input()))


# 숫자 원소 찾기 
if int(input()) in num :
    print('숫자 있음')
else :
    print('숫자 없음')




 



