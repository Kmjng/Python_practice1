# -*- coding: utf-8 -*-
"""
step04_set.py

set 특징 
 - 순서 없는 자료구조
 - 중복 허용 불가 
  형식) 변수 = {값1, 값2,...}
"""

# 1. set 생성 
st = {1, 3, 5, 1, 5} # 중복 허용 불가 
print(st, len(st)) # {1, 3, 5} 3

# for + set
for s in st :
    print(s, end = ' ') # 1 3 5
    
    
# 2. 중복 불가 
gender = ['남','여','남','여'] # list
gender

# list -> set
sgender = set(gender)
print(sgender) # {'남', '여'}


# 집합관련 
set1 = {1, 3, 4, 5, 7}
set2 = {3, 5}

set1.union(set2) #  합집합 : {1, 3, 4, 5, 7}
set1.difference(set2) # 차집합 : {1, 4, 7}
set1.intersection(set2) # 교집합 : {3, 5}

# 원소 추가 
set2.add(7)
print(set2) # {1, 3, 5, 7}

# 원소 삭제 
set2.discard(7) 
print(set2) # {1, 3, 5}






