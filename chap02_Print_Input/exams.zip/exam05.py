'''
문5) 다음과 같은 2개의 파일 경로를 대상으로 각각 파일명을 추출하여 
       출력하시오.

  <출력결과>
  파일명1: emp.xlsx
  파일명2: report.docx
'''

file_path1 = "/user/itwill/emp.xlsx"

file_path2 = "/home/user/documents/report.docx"

